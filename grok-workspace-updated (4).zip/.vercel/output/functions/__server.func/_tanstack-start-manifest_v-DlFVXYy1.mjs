//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DlFVXYy1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-JQDI5Pn_.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-JQDI5Pn_.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-YJz9cCm_.js"]
	}
} });
//#endregion
export { tsrStartManifest };
