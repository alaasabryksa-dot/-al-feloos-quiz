import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CFgeYmW2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function asset(path) {
	if (typeof window === "undefined") return `/${path}`;
	const prefixed = window.location.pathname.match(/^(\/hds-[a-z0-9]+-\d+-[a-z0-9]+)(?:\/|$)/i);
	return prefixed ? `${prefixed[1]}/${path}` : `/${path}`;
}
function Home() {
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		const load = (src) => new Promise((resolve, reject) => {
			const existing = document.querySelector(`script[data-feloos="${src}"]`);
			if (existing) {
				if (existing.getAttribute("data-loaded") === "1") resolve();
				else existing.addEventListener("load", () => resolve(), { once: true });
				return;
			}
			const script = document.createElement("script");
			script.src = asset(src);
			script.async = false;
			script.dataset.feloos = src;
			script.onload = () => {
				script.dataset.loaded = "1";
				resolve();
			};
			script.onerror = () => reject(new Error(src));
			document.body.appendChild(script);
		});
		(async () => {
			try {
				const w = window;
				if (!w.QUESTIONS) await load("questions.js");
				if (cancelled || w.__feloosBooted) return;
				await load("game.js");
			} catch {
				const toast = document.getElementById("toast");
				if (toast) {
					toast.hidden = false;
					toast.textContent = "اللعبة متعملتش. اقفل الصفحة وافتحها تاني.";
				}
			}
		})();
		return () => {
			cancelled = true;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			id: "app",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "phone",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "stack center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							className: "logo",
							src: "/logo.jpg",
							alt: ""
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "display gold",
							children: [
								"من سيربح",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"الفلوس"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "muted",
							children: "جاوب صح، اجمع جواهر، واطلب سحبها بعد المراجعة."
						})
					]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			id: "ad",
			hidden: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel",
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "ad-heading",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "coin",
						children: "5"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "ad-heading",
						children: "إعلان مقابل مكافأة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						id: "ad-title",
						className: "muted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"لو خلّصت الإعلان هتاخد ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "5 عملات للعب فقط" }),
						". مش جواهر ومش فلوس حقيقية. المكافأة بتتضاف مرة واحدة لما الإعلان نفسه يأكدها."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						id: "ad-status",
						className: "muted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stack",
						style: { marginTop: "1rem" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn gold",
							"data-act": "ad-watch",
							type: "button",
							children: "شاهد الإعلان"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn",
							"data-act": "ad-skip",
							type: "button",
							children: "تخطي"
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			id: "coins",
			hidden: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel",
				role: "dialog",
				"aria-modal": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "coin",
						children: "5"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "عملاتك خلصت" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "muted",
						children: "مينفعش تبدأ السؤال من غير 5 عملات. شاهد الإعلان لحد المكافأة عشان تاخد 5 عملات وتكمل."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stack",
						style: { marginTop: "1rem" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn gold",
							"data-act": "coins-yes",
							type: "button",
							children: "شاهد الإعلان"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "btn",
							"data-act": "coins-no",
							type: "button",
							children: "رجوع"
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			id: "toast",
			hidden: true
		})
	] });
}
//#endregion
export { Home as component };
