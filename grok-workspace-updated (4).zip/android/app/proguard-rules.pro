-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.feloos.quiz.MainActivity$Bridge { *; }
