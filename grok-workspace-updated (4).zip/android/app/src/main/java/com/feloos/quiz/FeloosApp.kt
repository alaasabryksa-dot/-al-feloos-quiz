package com.feloos.quiz

import android.app.Application
import android.os.Handler
import android.os.Looper
import com.google.android.gms.ads.MobileAds

class FeloosApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread {
            MobileAds.initialize(this) {
                val pending = synchronized(waiters) {
                    ready = true
                    waiters.toList().also { waiters.clear() }
                }
                val main = Handler(Looper.getMainLooper())
                pending.forEach { block -> main.post(block) }
            }
        }.start()
    }

    companion object {
        @Volatile
        var ready: Boolean = false
        private val waiters = mutableListOf<() -> Unit>()

        fun whenReady(block: () -> Unit) {
            val runNow = synchronized(waiters) {
                if (ready) true else {
                    waiters += block
                    false
                }
            }
            if (runNow) Handler(Looper.getMainLooper()).post(block)
        }
    }
}
