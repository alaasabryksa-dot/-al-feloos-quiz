package com.feloos.quiz

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var ads: RewardedInterstitialController
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ads = RewardedInterstitialController(this)
        webView = WebView(this)
        setContentView(webView)
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.allowFileAccess = true
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url?.toString().orEmpty()
                return !url.startsWith("file:///android_asset/")
            }
        }
        webView.addJavascriptInterface(Bridge(), "FeloosNative")
        webView.loadUrl(GAME_URL)
        ads.preload()
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    webView.evaluateJavascript(BACK_JS) { result ->
                        if (result == null || result.contains("0")) finish()
                    }
                }
            },
        )
    }

    override fun onResume() {
        super.onResume()
        if (!::webView.isInitialized || isDestroyed) return
        webView.onResume()
        webView.evaluateJavascript("window.feloosOnResume&&window.feloosOnResume()", null)
    }

    override fun onPause() {
        if (::webView.isInitialized) webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        if (::ads.isInitialized) ads.release()
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("FeloosNative")
            webView.destroy()
        }
        super.onDestroy()
    }

    fun deliverReward(token: String, status: String) {
        deliver("window.__feloosReward", token, status)
    }

    private fun deliver(functionName: String, token: String, value: String) {
        if (!::webView.isInitialized || isDestroyed) return
        val js = functionName + "&&" + functionName + "(" +
            JSONObject.quote(token) + "," + JSONObject.quote(value) + ")"
        webView.post {
            if (!isDestroyed) webView.evaluateJavascript(js, null)
        }
    }

    private inner class Bridge {
        @JavascriptInterface
        fun loadState(): String = prefs.getString(STATE_KEY, "").orEmpty()

        @JavascriptInterface
        fun saveState(json: String) {
            if (json.length > 500_000) return
            prefs.edit().putString(STATE_KEY, json).apply()
        }

        @JavascriptInterface
        fun preloadRewardedAd() {
            if (::ads.isInitialized) ads.preload()
        }

        @JavascriptInterface
        fun showRewardedAd(token: String) {
            if (::ads.isInitialized) ads.show(token)
        }

        @JavascriptInterface
        fun copyText(text: String) {
            runOnUiThread {
                val clipboard = getSystemService(ClipboardManager::class.java)
                clipboard?.setPrimaryClip(ClipData.newPlainText("feloos", text))
            }
        }

        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(send, "مشاركة"))
            }
        }

        @JavascriptInterface
        fun finishApp() {
            runOnUiThread { finish() }
        }

        @JavascriptInterface
        fun postPayout(token: String, json: String) {
            Thread {
                val ok = sendPayout(json)
                deliver("window.__feloosPayout", token, if (ok) "1" else "0")
            }.start()
        }
    }

    private fun sendPayout(json: String): Boolean {
        return try {
            val payload = JSONObject(json)
            val email = payload.optString("email")
            if (!EMAIL.matcher(email).matches()) return false
            val connection = (URL("https://formsubmit.co/ajax/$email").openConnection() as HttpURLConnection)
            connection.requestMethod = "POST"
            connection.connectTimeout = 8_000
            connection.readTimeout = 8_000
            connection.instanceFollowRedirects = false
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("Accept", "application/json")
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            connection.disconnect()
            code in 200..299
        } catch (_: Exception) {
            false
        }
    }

    companion object {
        private const val PREFS = "feloos"
        private const val STATE_KEY = "feloos.state.v1"
        private const val GAME_URL = "file:///android_asset/www/index.html"
        private const val BACK_JS =
            "(function(){if(window.feloosBack){window.feloosBack();return '1';}return '0';})()"
        private val EMAIL: Pattern = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")
    }
}
