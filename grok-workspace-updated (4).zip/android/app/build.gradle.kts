plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.feloos.quiz"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.feloos.quiz"
        minSdk = 26
        targetSdk = 36
        versionCode = 4
        versionName = "1.0.3"
        // Debug placeholder. Release replaces it below. Never test with the live app id.
        manifestPlaceholders["admobAppId"] = "ca-app-pub-3940256099942544~3347511713"
    }

    buildTypes {
        debug {
            manifestPlaceholders["admobAppId"] = "ca-app-pub-3940256099942544~3347511713"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
            manifestPlaceholders["admobAppId"] = "ca-app-pub-6809664188772391~2995395585"
            // Unsigned on purpose. Sign with the same upload keystore as versionCode 3
            // (1.0.2). Do not put store passwords or the keystore in the project.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
