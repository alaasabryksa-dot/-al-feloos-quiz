import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/")({ component: Home });

function asset(path: string) {
  if (typeof window === "undefined") return `/${path}`;
  const prefixed = window.location.pathname.match(/^(\/hds-[a-z0-9]+-\d+-[a-z0-9]+)(?:\/|$)/i);
  return prefixed ? `${prefixed[1]}/${path}` : `/${path}`;
}

function Home() {
  useEffect(() => {
    let cancelled = false;
    const load = (src: string) =>
      new Promise<void>((resolve, reject) => {
        const existing = document.querySelector(`script[data-feloos="${src}"]`);
        if (existing) {
          if (existing.getAttribute("data-loaded") === "1") resolve();
          else existing.addEventListener("load", () => resolve(), { once: true });
          return;
        }
        const script = document.createElement("script");
        script.src = asset(src);
        script.async = false;
        script.dataset.feloos = src;
        script.onload = () => {
          script.dataset.loaded = "1";
          resolve();
        };
        script.onerror = () => reject(new Error(src));
        document.body.appendChild(script);
      });
    (async () => {
      try {
        const w = window as Window & { QUESTIONS?: unknown; __feloosBooted?: boolean };
        if (!w.QUESTIONS) await load("questions.js");
        if (cancelled || w.__feloosBooted) return;
        await load("game.js");
      } catch {
        const toast = document.getElementById("toast");
        if (toast) {
          toast.hidden = false;
          toast.textContent = "اللعبة متعملتش. اقفل الصفحة وافتحها تاني.";
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <>
      <div id="app">
        <div className="phone">
          <main className="stack center">
            <img className="logo" src="/logo.jpg" alt="" />
            <h1 className="display gold">
              من سيربح
              <br />
              الفلوس
            </h1>
            <p className="muted">جاوب صح، اجمع جواهر، واطلب سحبها بعد المراجعة.</p>
          </main>
        </div>
      </div>
      <div id="ad" hidden>
        <div className="panel" role="dialog" aria-modal="true" aria-labelledby="ad-heading">
          <div className="coin">5</div>
          <h2 id="ad-heading">إعلان مقابل مكافأة</h2>
          <p id="ad-title" className="muted"></p>
          <p>
            لو خلّصت الإعلان هتاخد <b>5 عملات للعب فقط</b>. مش جواهر ومش فلوس حقيقية. المكافأة بتتضاف مرة واحدة لما الإعلان نفسه يأكدها.
          </p>
          <p id="ad-status" className="muted"></p>
          <div className="stack" style={{ marginTop: "1rem" }}>
            <button className="btn gold" data-act="ad-watch" type="button">
              شاهد الإعلان
            </button>
            <button className="btn" data-act="ad-skip" type="button">
              تخطي
            </button>
          </div>
        </div>
      </div>
      <div id="coins" hidden>
        <div className="panel" role="dialog" aria-modal="true">
          <div className="coin">5</div>
          <h2>عملاتك خلصت</h2>
          <p className="muted">مينفعش تبدأ السؤال من غير 5 عملات. شاهد الإعلان لحد المكافأة عشان تاخد 5 عملات وتكمل.</p>
          <div className="stack" style={{ marginTop: "1rem" }}>
            <button className="btn gold" data-act="coins-yes" type="button">
              شاهد الإعلان
            </button>
            <button className="btn" data-act="coins-no" type="button">
              رجوع
            </button>
          </div>
        </div>
      </div>
      <p id="toast" hidden></p>
    </>
  );
}
